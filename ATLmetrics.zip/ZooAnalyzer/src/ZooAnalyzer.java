import static java.text.DateFormat.MEDIUM;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Vector;

import org.apache.commons.io.FileUtils;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.m2m.atl.core.ATLCoreException;

import Metrics.Metrics;
import Metrics.MetricsPackage;
import Metrics.SimpleIntegerMetric;
import Metrics.SimpleMetric;


public class ZooAnalyzer {
	
	// Folder which contains the ATL Zoo information
	static File dir;
	
	// Vectors for processed files
	static Vector<File> allFiles = new Vector<File>();
	static Vector<File> atlFiles = new Vector<File>();
	static Vector<File> launchFiles = new Vector<File>();
	static Vector<File> metricsFiles = new Vector<File>();
	static Vector<File> buildFiles = new Vector<File>();
	static Vector<File> ecoreFiles = new Vector<File>();
	static Vector<File> km3Files = new Vector<File>();
	
	// Metrics for transformations 
	static int fileAmount = 0;
	static int trafoAmount = 0;
	static int query = 0;
	static int library = 0;
	static int trafoWithAbstractRules = 0;
	static int trafoWithoutInheritance = 0;
	static int trafoWithLibraryImport = 0;
	static int libraryImport = 0;
	static int trafoWithHelper = 0; 
	static int trafoWithOutHelper = 0;
	static int trafoWithInhertingRules = 0;
	static int trafoWithSuperimposition = 0;
	static int higherOrderTrafo = 0;
	static int trafoChains = 0;
	static int processedMetamodels = 0;
	
	// Data structures for storing metric values 
	static Vector<String> trafoNames = new Vector<String>();
	static Vector<Integer> trafoInputModels = new Vector<Integer>();
	static Vector<Integer> trafoOutputModels = new Vector<Integer>();
	static Vector<Integer> trafoRuleAmount = new Vector<Integer>();
	static Vector<Integer> trafoHelperAmount = new Vector<Integer>();
	static Vector<String> trafoType = new Vector<String>();
	static Vector<Boolean> useImport = new Vector<Boolean>();
	static Vector<Boolean> useHelper = new Vector<Boolean>();
	static Vector<Boolean> useInheritance = new Vector<Boolean>();
	static Vector<Boolean> useSuperImposition = new Vector<Boolean>();
	static Vector<Boolean> isHOT = new Vector<Boolean>();
	static Vector<String> lastModified = new Vector<String>();

	private static HashMap<String, Integer> mmInheritance;
	private static HashMap<String, Integer> mmClasses;
	
	static Vector<String> transformationChains = new Vector<String>();
	
	public static void main(String[] args) throws ATLCoreException, IOException {
		
		long start = System.currentTimeMillis();
		
		ZooAnalyzer.dir = new File(args[0]);
		
		loadFiles(dir);
		clusterFiles(dir);
		
		// Read ATL Transformations
		processATLFiles();
		
		// Read Build Files
		processBuildFiles();		
		
		// Read Launch Files
		processLaunchFiles();
		
		// Process Metrics Files
		processTransformationMetricsFiles();
		
		// Process Ecore & KM3 Files
		processEcoreFiles();
		processKM3Files();
		
		// Print results of analysis to the Console
		printResults();		
		
		System.out.println("Duration of Repository Mining in ms: " + (System.currentTimeMillis() - start));
	}

	private static void printResults() {
		System.out.println("****************************************************");
		System.out.println("Processed Transformations:\t" + (trafoAmount - query - library));
		System.out.println("Processed Queries:\t" + query);
		System.out.println("Processed Libraries:\t" + library);
		System.out.println("Transformations with Helpers:\t" + trafoWithHelper);
		System.out.println("Transformations with Abstract Rules:\t" + trafoWithAbstractRules);
		System.out.println("Transformations with Inheritance:\t" + trafoWithInhertingRules);
		System.out.println("Transformations with Library Import:\t" + trafoWithLibraryImport);
		System.out.println("Processed Transformation Chains:\t" + trafoChains);
		System.out.println("Processed Higher-order Transformations:\t" + higherOrderTrafo);
		System.out.println("****************************************************");		
		
		System.out.println("\n");
		
		System.out.println("****************************************************");
		System.out.println("Transformations + Meta-information");
	
		Iterator<String> trafoNamesIter = trafoNames.iterator();
		Iterator<Integer> trafoInSizeIter = trafoInputModels.iterator();
		Iterator<Integer> trafoOutSizeIter = trafoOutputModels.iterator();
		Iterator<Integer> trafoRuleSizeIter = trafoRuleAmount.iterator();
		Iterator<Integer> trafoHelperSizeIter = trafoHelperAmount.iterator();
		Iterator<Boolean> useInheritanceIter = useInheritance.iterator();
		Iterator<Boolean> useHelperIter = useHelper.iterator();
		Iterator<String> trafoTypeIter = trafoType.iterator();
		Iterator<Boolean> superimposeIter = useSuperImposition.iterator();
		Iterator<Boolean> useImportIter = useImport.iterator();
		Iterator<Boolean> isHOTIter = isHOT.iterator();
		Iterator<String> lastModifiedIter = lastModified.iterator();
		
		
		System.out.print("Name\t TrafoType\t Last Modified\t #Rules\t #Helpers\t Superimposition\t Inheritance\t Helpers\t Import\t IsHot\t InModels\t OutModels\t");

		while(trafoNamesIter.hasNext()){
			try {
				System.out.print("" + trafoNamesIter.next() + "\t" + trafoTypeIter.next() + "\t" + lastModifiedIter.next() + "\t");
				System.out.print("" + trafoRuleSizeIter.next() + "\t" + trafoHelperSizeIter.next());
				System.out.println("\t" + superimposeIter.next() + "\t"   + useInheritanceIter.next() + "\t" + useHelperIter.next() 
						+"\t" + useImportIter.next() +"\t" + isHOTIter.next()
						+"\t" + trafoInSizeIter.next() +"\t" + trafoOutSizeIter.next());
			} catch (Exception e) {
				System.out.println("ERROR in Data Vectors");
			}
		}
		System.out.println("***************************************************");
		
		System.out.println("\n");
		
		System.out.println("***************************************************");
		System.out.println("Transformation Chains identified in Build Scripts");
		Iterator<String> trafoChainIter = transformationChains.iterator();
		while(trafoChainIter.hasNext()){
			System.out.println(trafoChainIter.next());
		}
		System.out.println("***************************************************");

		System.out.println("\n");
		
		System.out.println("***************************************************");
		System.out.println("Processed Metamodels");
		Set<Entry<String, Integer>> entrySet1 = mmInheritance.entrySet();
		Set<Entry<String, Integer>> entrySet2 = mmClasses.entrySet();
		Iterator<Entry<String, Integer>> iter1 = entrySet1.iterator();
		Iterator<Entry<String, Integer>> iter2 = entrySet2.iterator();
		
		while(iter1.hasNext() && iter2.hasNext()){
			Entry<String, Integer> entry1 = iter1.next();
			Entry<String, Integer> entry2 = iter2.next();
			System.out.println(entry1.getKey() + "\t" + entry2.getValue()
					+ "\t\t" + entry1.getValue());
		}
		System.out.println("****************************************************");
		
		System.out.println("\n");
		
		System.out.println("***************************************************");
		System.out.println("Processed Files (including generated xmi/metrics files):\t" + fileAmount);
		
		System.out.println("Amound of ATL files:\t" + atlFiles.size());
		System.out.println("Amound of Launch files:\t" + launchFiles.size());
		System.out.println("Amound of Build files:\t" + buildFiles.size());
		System.out.println("Amound of Ecore files:\t" + ecoreFiles.size());
		System.out.println("Amound of KM3 files:\t" + km3Files.size());

		System.out.println("***************************************************");
	}

	private static void processTransformationMetricsFiles() throws IOException {
		MetricsPackage.eINSTANCE.eClass();
		Resource.Factory.Registry reg = Resource.Factory.Registry.INSTANCE;
		Map<String, Object> m = reg.getExtensionToFactoryMap();
		m.put("metric", new XMIResourceFactoryImpl());
		ResourceSet resSet = new ResourceSetImpl();
	
		Iterator<File> metricsFilesIter = metricsFiles.iterator();
		while(metricsFilesIter.hasNext()){
			File currentFile = metricsFilesIter.next();
			Resource resource = resSet.getResource(URI
					.createURI(currentFile.getPath()), true);
			Metrics metrics = (Metrics) resource.getContents().get(0);
			
			trafoNames.add(metrics.getTrafoName());
			trafoAmount++;
			

			
			if(metrics.getTrafoKind() == 3){
				// transformation
				Iterator<SimpleMetric> metricIter = metrics.getSimpleMetrics().iterator();
				while(metricIter.hasNext()){
					SimpleMetric metric = metricIter.next();
					if(! (metric instanceof SimpleIntegerMetric)){continue;}
					SimpleIntegerMetric metric2 = (SimpleIntegerMetric) metric;
					if(metric2.getMetric().equals("Number of Transformation Rules")){
						trafoRuleAmount.add(metric2.getValue());
					}
					else if(metric2.getMetric().equals("Number of Input Models")){
						trafoInputModels.add(metric2.getValue());
					}
					else if(metric2.getMetric().equals("Number of Output Models")){
						trafoOutputModels.add(metric2.getValue());
					}
					else if(metric2.getMetric().equals("Number of Helpers")){
						if (metric2.getValue() > 0){
							trafoWithHelper++;
						}
						useHelper.add(metric2.getValue() > 0);
						trafoHelperAmount.add(metric2.getValue());
					}
					else if(metric2.getMetric().equals("Number of Abstract Transformation Rules")){
						if (metric2.getValue() > 0){
							trafoWithAbstractRules++;
						}
					}
					else if(metric2.getMetric().equals("Number of Inheriting Transformation Rules")){
						if (metric2.getValue() > 0){
							trafoWithInhertingRules++;
						}
						useInheritance.add(metric2.getValue() > 0);
					}
					else if(metric2.getMetric().equals("Number of Unit Refs")){
						if (metric2.getValue() > 0){
							trafoWithLibraryImport++;
						}
						useImport.add(metric2.getValue() > 0);
					}	
//					else if(metric2.getMetric().equals("Number of Lazy Matched Rules (Including Unique)")){
//						if (metric2.getValue() > 0) System.out.println(metrics.getTrafoName() + metric2.getValue());
//					}
//					else if(metric2.getMetric().equals("Number of Called Rules")){
//						if (metric2.getValue() > 0) System.out.println(metrics.getTrafoName() + metric2.getValue());
//					}
					else if(metric2.getMetric().equals("Number of Rules with a Filter Condition on the Input Pattern")){
						if (metric2.getValue() > 0) System.out.println(metrics.getTrafoName() + metric2.getValue());
					}
					
					
				}
				trafoType.add("Transformation");
				if(metrics.isHigherOrder()){
					higherOrderTrafo++;
				}
				isHOT.add(metrics.isHigherOrder());

			}else if (metrics.getTrafoKind() == 2){
				//library
				Iterator<SimpleMetric> metricIter = metrics.getSimpleMetrics().iterator();
				while(metricIter.hasNext()){
					SimpleMetric metric = metricIter.next();
					if(! (metric instanceof SimpleIntegerMetric)){continue;}
					SimpleIntegerMetric metric2 = (SimpleIntegerMetric) metric;
					if(metric2.getMetric().equals("Number of Helpers")){
						trafoHelperAmount.add(metric2.getValue());
					}
				}
				library++;
				trafoType.add("Library");
				trafoRuleAmount.add(0);
				useInheritance.add(false);
				useHelper.add(false);
				useImport.add(false);
				isHOT.add(false);
				trafoInputModels.add(0);
				trafoOutputModels.add(0);
			}else{
				//query
				Iterator<SimpleMetric> metricIter = metrics.getSimpleMetrics().iterator();
				while(metricIter.hasNext()){
					SimpleMetric metric = metricIter.next();
					if(! (metric instanceof SimpleIntegerMetric)){continue;}
					SimpleIntegerMetric metric2 = (SimpleIntegerMetric) metric;
					if(metric2.getMetric().equals("Number of Helpers")){
						trafoHelperAmount.add(metric2.getValue());
					}
				}
				query++;
				trafoType.add("Query");
				useImport.add(false);
				isHOT.add(false);
				trafoInputModels.add(0);
				trafoOutputModels.add(0);
				trafoRuleAmount.add(0);
				useInheritance.add(false);
				useHelper.add(false);
			}
			
			Iterator<File> launchFilesIter = launchFiles.iterator();
			boolean superimpose = false;
			while(launchFilesIter.hasNext()){
				File file = launchFilesIter.next();
				String content = FileUtils.readFileToString(file, "UTF-8");
				if(content.indexOf("listAttribute key=\"Superimpose\"") > 0 && content.indexOf("<listAttribute key=\"Superimpose\"/>") < 0 && content.indexOf(currentFile.getName().replaceFirst(".metrics", "")) > 0){
					superimpose = true;
					break;
				}
			}
			useSuperImposition.add(superimpose);

		}
	}

	private static void processLaunchFiles() throws FileNotFoundException,
			ATLCoreException, IOException {

		Iterator<File> launchFilesIter = launchFiles.iterator();
		while(launchFilesIter.hasNext()){
			File file = launchFilesIter.next();
			String content = FileUtils.readFileToString(file, "UTF-8");
			if(content.indexOf("listAttribute key=\"Superimpose\"") > 0 && content.indexOf("<listAttribute key=\"Superimpose\"/>") < 0){
				trafoWithSuperimposition++;
			}
		}
	}

	private static void processBuildFiles() throws FileNotFoundException,
			ATLCoreException, IOException {

		Iterator<File> buildfilesIter = buildFiles.iterator();
		while(buildfilesIter.hasNext()){
			File currentFile = buildfilesIter.next(); 
			String content = FileUtils.readFileToString(currentFile, "UTF-8");
			if(content.indexOf("<am3.atl") > 0 && content.indexOf("<am3.atl", content.indexOf("<am3.atl") + 1) > 0){
				trafoChains++;
				transformationChains.add(currentFile.getAbsolutePath());
			}else if(content.indexOf("<atl.launch") > 0 && content.indexOf("<atl.launch", content.indexOf("<atl.launch") + 1) > 0){
				trafoChains++;
				transformationChains.add(currentFile.getAbsolutePath());				
			}
		}
	}

	private static void processATLFiles() throws FileNotFoundException,
			ATLCoreException {

		Iterator<File> atlfilesIter = atlFiles.iterator();
		while(atlfilesIter.hasNext()){
			File currentFile = atlfilesIter.next(); 
			MetricsRunner.setModels(currentFile);
			MetricsRunner.computeMetrics4Trafo();
			
			Date date = new Date(currentFile.lastModified());
			DateFormat df = DateFormat.getDateInstance(MEDIUM);
			lastModified.add(df.format(date));
		}
	}
	
	private static void processEcoreFiles() throws FileNotFoundException,
	ATLCoreException {

		EcorePackage.eINSTANCE.eClass();
	    Resource.Factory.Registry reg = Resource.Factory.Registry.INSTANCE;
	    Map<String, Object> m = reg.getExtensionToFactoryMap();
	    m.put("ecore", new XMIResourceFactoryImpl());
        ResourceSet resSet = new ResourceSetImpl();

		mmInheritance = new HashMap<String, Integer>();
		mmClasses = new HashMap<String, Integer>();

		Iterator<File> ecoreFilesIter = ecoreFiles.iterator();
		while(ecoreFilesIter.hasNext()){
			File currentFile = ecoreFilesIter.next(); 
			Resource metamodel = null;
			try{
				metamodel = resSet.getResource(URI.createFileURI(currentFile.getAbsolutePath()), true);
			}catch(Exception e){
				continue;
			}
			processedMetamodels++;

			int packageAmount = metamodel.getContents().size();
			int inheritance = 0;
			int classes = 0;
			for(int i = 0; i < packageAmount; i++){
				try{
					EPackage pack = (EPackage) metamodel.getContents().get(i);
					Iterator<EClassifier> classIter = pack.getEClassifiers().iterator();
					while(classIter.hasNext()){
						EClassifier classifier = classIter.next();
						if(classifier instanceof EClass){
							EClass clazz = (EClass) classifier;
							inheritance = inheritance + clazz.getESuperTypes().size();
							classes++;
						}
					}
				}catch(Exception e){
					break;
				}
			}
			if(packageAmount != 0){ 
				mmInheritance.put(currentFile.getName(), inheritance);
				mmClasses.put(currentFile.getName(), classes);
			}
		}
	}
	
	private static void processKM3Files() throws ATLCoreException, IOException {
		
		Iterator<File> km3FilesIter = km3Files.iterator();
		while(km3FilesIter.hasNext()){
			File currentFile = km3FilesIter.next(); 
			String content = FileUtils.readFileToString(currentFile, "UTF-8");
			int inheritance = 0;
			if(content.split("extends").length > 1){
				inheritance = content.split("extends").length;
			}
			mmInheritance.put(currentFile.getName().replaceFirst(".km3", ".ecore"), inheritance);
			mmClasses.put(currentFile.getName().replaceFirst(".km3", ".ecore"), content.split("class").length);
		}
	}

	private static void clusterFiles(File dir) throws FileNotFoundException, ATLCoreException {

		Iterator<File> fileIterator = allFiles.iterator();
		while(fileIterator.hasNext()){
			File file = fileIterator.next();
			if(!file.isFile()) continue;
			fileAmount++;
			String name = file.getName();
			if(name.indexOf('.') == -1) continue;
			String extension = name.substring(name.lastIndexOf('.'),name.length());
	
			if(extension.equals(".atl")){
				atlFiles.add(file);
			}else if (extension.equals(".launch")){
				launchFiles.add(file);
			}else if (name.contains("build") && extension.equals(".xml")){
				buildFiles.add(file);
			}else if (extension.equals(".ecore")){
				ecoreFiles.add(file);
			}else if (extension.equals(".km3")){
				km3Files.add(file);
			}
		}
	}

	private static void loadFiles(File dir) throws FileNotFoundException, ATLCoreException {		
		File[] files = dir.listFiles();
		if (files != null){
			for (int i=0; i<files.length; i++){
				File file = files[i];
				allFiles.add(file);
				if(file.isDirectory()){
					loadFiles(file);
				}
			}
		}
	}
}
