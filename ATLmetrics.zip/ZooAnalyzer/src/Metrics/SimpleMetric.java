/**
 */
package Metrics;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Simple Metric</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see Metrics.MetricsPackage#getSimpleMetric()
 * @model abstract="true"
 * @generated
 */
public interface SimpleMetric extends Metric {
} // SimpleMetric
