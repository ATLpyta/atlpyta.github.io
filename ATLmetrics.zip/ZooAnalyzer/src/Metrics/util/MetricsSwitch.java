/**
 */
package Metrics.util;

import Metrics.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see Metrics.MetricsPackage
 * @generated
 */
public class MetricsSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static MetricsPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MetricsSwitch() {
		if (modelPackage == null) {
			modelPackage = MetricsPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @parameter ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
			case MetricsPackage.METRICS: {
				Metrics metrics = (Metrics)theEObject;
				T result = caseMetrics(metrics);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case MetricsPackage.METRIC: {
				Metric metric = (Metric)theEObject;
				T result = caseMetric(metric);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case MetricsPackage.SIMPLE_METRIC: {
				SimpleMetric simpleMetric = (SimpleMetric)theEObject;
				T result = caseSimpleMetric(simpleMetric);
				if (result == null) result = caseMetric(simpleMetric);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case MetricsPackage.SIMPLE_INTEGER_METRIC: {
				SimpleIntegerMetric simpleIntegerMetric = (SimpleIntegerMetric)theEObject;
				T result = caseSimpleIntegerMetric(simpleIntegerMetric);
				if (result == null) result = caseSimpleMetric(simpleIntegerMetric);
				if (result == null) result = caseMetric(simpleIntegerMetric);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case MetricsPackage.SIMPLE_REAL_METRIC: {
				SimpleRealMetric simpleRealMetric = (SimpleRealMetric)theEObject;
				T result = caseSimpleRealMetric(simpleRealMetric);
				if (result == null) result = caseSimpleMetric(simpleRealMetric);
				if (result == null) result = caseMetric(simpleRealMetric);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case MetricsPackage.AGGREGATED_INTEGER_METRIC: {
				AggregatedIntegerMetric aggregatedIntegerMetric = (AggregatedIntegerMetric)theEObject;
				T result = caseAggregatedIntegerMetric(aggregatedIntegerMetric);
				if (result == null) result = caseAggregatedMetric(aggregatedIntegerMetric);
				if (result == null) result = caseMetric(aggregatedIntegerMetric);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case MetricsPackage.AGGREGATED_REAL_METRIC: {
				AggregatedRealMetric aggregatedRealMetric = (AggregatedRealMetric)theEObject;
				T result = caseAggregatedRealMetric(aggregatedRealMetric);
				if (result == null) result = caseAggregatedMetric(aggregatedRealMetric);
				if (result == null) result = caseMetric(aggregatedRealMetric);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case MetricsPackage.AGGREGATED_METRIC: {
				AggregatedMetric aggregatedMetric = (AggregatedMetric)theEObject;
				T result = caseAggregatedMetric(aggregatedMetric);
				if (result == null) result = caseMetric(aggregatedMetric);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			default: return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Metrics</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Metrics</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMetrics(Metrics object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Metric</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Metric</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMetric(Metric object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Simple Metric</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Simple Metric</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSimpleMetric(SimpleMetric object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Simple Integer Metric</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Simple Integer Metric</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSimpleIntegerMetric(SimpleIntegerMetric object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Simple Real Metric</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Simple Real Metric</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSimpleRealMetric(SimpleRealMetric object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Aggregated Integer Metric</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Aggregated Integer Metric</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAggregatedIntegerMetric(AggregatedIntegerMetric object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Aggregated Real Metric</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Aggregated Real Metric</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAggregatedRealMetric(AggregatedRealMetric object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Aggregated Metric</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Aggregated Metric</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAggregatedMetric(AggregatedMetric object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //MetricsSwitch
