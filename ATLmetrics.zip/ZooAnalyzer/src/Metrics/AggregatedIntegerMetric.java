/**
 */
package Metrics;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Aggregated Integer Metric</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link Metrics.AggregatedIntegerMetric#getMinimum <em>Minimum</em>}</li>
 *   <li>{@link Metrics.AggregatedIntegerMetric#getMaximum <em>Maximum</em>}</li>
 *   <li>{@link Metrics.AggregatedIntegerMetric#getMedian <em>Median</em>}</li>
 * </ul>
 * </p>
 *
 * @see Metrics.MetricsPackage#getAggregatedIntegerMetric()
 * @model
 * @generated
 */
public interface AggregatedIntegerMetric extends AggregatedMetric {
	/**
	 * Returns the value of the '<em><b>Minimum</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Minimum</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Minimum</em>' attribute.
	 * @see #setMinimum(int)
	 * @see Metrics.MetricsPackage#getAggregatedIntegerMetric_Minimum()
	 * @model required="true"
	 * @generated
	 */
	int getMinimum();

	/**
	 * Sets the value of the '{@link Metrics.AggregatedIntegerMetric#getMinimum <em>Minimum</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Minimum</em>' attribute.
	 * @see #getMinimum()
	 * @generated
	 */
	void setMinimum(int value);

	/**
	 * Returns the value of the '<em><b>Maximum</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Maximum</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Maximum</em>' attribute.
	 * @see #setMaximum(int)
	 * @see Metrics.MetricsPackage#getAggregatedIntegerMetric_Maximum()
	 * @model required="true"
	 * @generated
	 */
	int getMaximum();

	/**
	 * Sets the value of the '{@link Metrics.AggregatedIntegerMetric#getMaximum <em>Maximum</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Maximum</em>' attribute.
	 * @see #getMaximum()
	 * @generated
	 */
	void setMaximum(int value);

	/**
	 * Returns the value of the '<em><b>Median</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Median</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Median</em>' attribute.
	 * @see #setMedian(int)
	 * @see Metrics.MetricsPackage#getAggregatedIntegerMetric_Median()
	 * @model required="true"
	 * @generated
	 */
	int getMedian();

	/**
	 * Sets the value of the '{@link Metrics.AggregatedIntegerMetric#getMedian <em>Median</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Median</em>' attribute.
	 * @see #getMedian()
	 * @generated
	 */
	void setMedian(int value);

} // AggregatedIntegerMetric
