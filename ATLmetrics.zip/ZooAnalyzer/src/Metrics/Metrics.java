/**
 */
package Metrics;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Metrics</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link Metrics.Metrics#getSimpleMetrics <em>Simple Metrics</em>}</li>
 *   <li>{@link Metrics.Metrics#getAggregatedIntegerMetrics <em>Aggregated Integer Metrics</em>}</li>
 *   <li>{@link Metrics.Metrics#getAggregatedRealMetrics <em>Aggregated Real Metrics</em>}</li>
 *   <li>{@link Metrics.Metrics#getTrafoName <em>Trafo Name</em>}</li>
 *   <li>{@link Metrics.Metrics#getTrafoKind <em>Trafo Kind</em>}</li>
 *   <li>{@link Metrics.Metrics#isHigherOrder <em>Higher Order</em>}</li>
 * </ul>
 * </p>
 *
 * @see Metrics.MetricsPackage#getMetrics()
 * @model
 * @generated
 */
public interface Metrics extends EObject {
	/**
	 * Returns the value of the '<em><b>Simple Metrics</b></em>' containment reference list.
	 * The list contents are of type {@link Metrics.SimpleMetric}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Simple Metrics</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Simple Metrics</em>' containment reference list.
	 * @see Metrics.MetricsPackage#getMetrics_SimpleMetrics()
	 * @model containment="true"
	 * @generated
	 */
	EList<SimpleMetric> getSimpleMetrics();

	/**
	 * Returns the value of the '<em><b>Aggregated Integer Metrics</b></em>' containment reference list.
	 * The list contents are of type {@link Metrics.AggregatedIntegerMetric}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Aggregated Integer Metrics</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Aggregated Integer Metrics</em>' containment reference list.
	 * @see Metrics.MetricsPackage#getMetrics_AggregatedIntegerMetrics()
	 * @model containment="true"
	 * @generated
	 */
	EList<AggregatedIntegerMetric> getAggregatedIntegerMetrics();

	/**
	 * Returns the value of the '<em><b>Aggregated Real Metrics</b></em>' containment reference list.
	 * The list contents are of type {@link Metrics.AggregatedRealMetric}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Aggregated Real Metrics</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Aggregated Real Metrics</em>' containment reference list.
	 * @see Metrics.MetricsPackage#getMetrics_AggregatedRealMetrics()
	 * @model containment="true"
	 * @generated
	 */
	EList<AggregatedRealMetric> getAggregatedRealMetrics();

	/**
	 * Returns the value of the '<em><b>Trafo Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Trafo Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trafo Name</em>' attribute.
	 * @see #setTrafoName(String)
	 * @see Metrics.MetricsPackage#getMetrics_TrafoName()
	 * @model required="true"
	 * @generated
	 */
	String getTrafoName();

	/**
	 * Sets the value of the '{@link Metrics.Metrics#getTrafoName <em>Trafo Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Trafo Name</em>' attribute.
	 * @see #getTrafoName()
	 * @generated
	 */
	void setTrafoName(String value);

	/**
	 * Returns the value of the '<em><b>Trafo Kind</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Trafo Kind</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trafo Kind</em>' attribute.
	 * @see #setTrafoKind(int)
	 * @see Metrics.MetricsPackage#getMetrics_TrafoKind()
	 * @model
	 * @generated
	 */
	int getTrafoKind();

	/**
	 * Sets the value of the '{@link Metrics.Metrics#getTrafoKind <em>Trafo Kind</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Trafo Kind</em>' attribute.
	 * @see #getTrafoKind()
	 * @generated
	 */
	void setTrafoKind(int value);

	/**
	 * Returns the value of the '<em><b>Higher Order</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Higher Order</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Higher Order</em>' attribute.
	 * @see #setHigherOrder(boolean)
	 * @see Metrics.MetricsPackage#getMetrics_HigherOrder()
	 * @model
	 * @generated
	 */
	boolean isHigherOrder();

	/**
	 * Sets the value of the '{@link Metrics.Metrics#isHigherOrder <em>Higher Order</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Higher Order</em>' attribute.
	 * @see #isHigherOrder()
	 * @generated
	 */
	void setHigherOrder(boolean value);

} // Metrics
