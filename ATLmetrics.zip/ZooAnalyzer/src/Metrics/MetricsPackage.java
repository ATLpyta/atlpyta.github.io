/**
 */
package Metrics;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import Metrics.impl.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see Metrics.MetricsFactory
 * @model kind="package"
 * @generated
 */
public interface MetricsPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "Metrics";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "Metrics";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "Metrics";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	MetricsPackage eINSTANCE = MetricsPackageImpl.init();

	/**
	 * The meta object id for the '{@link Metrics.impl.MetricsImpl <em>Metrics</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Metrics.impl.MetricsImpl
	 * @see Metrics.impl.MetricsPackageImpl#getMetrics()
	 * @generated
	 */
	int METRICS = 0;

	/**
	 * The feature id for the '<em><b>Simple Metrics</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METRICS__SIMPLE_METRICS = 0;

	/**
	 * The feature id for the '<em><b>Aggregated Integer Metrics</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METRICS__AGGREGATED_INTEGER_METRICS = 1;

	/**
	 * The feature id for the '<em><b>Aggregated Real Metrics</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METRICS__AGGREGATED_REAL_METRICS = 2;

	/**
	 * The feature id for the '<em><b>Trafo Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METRICS__TRAFO_NAME = 3;

	/**
	 * The feature id for the '<em><b>Trafo Kind</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METRICS__TRAFO_KIND = 4;

	/**
	 * The feature id for the '<em><b>Higher Order</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METRICS__HIGHER_ORDER = 5;

	/**
	 * The number of structural features of the '<em>Metrics</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METRICS_FEATURE_COUNT = 6;

	/**
	 * The meta object id for the '{@link Metrics.impl.MetricImpl <em>Metric</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Metrics.impl.MetricImpl
	 * @see Metrics.impl.MetricsPackageImpl#getMetric()
	 * @generated
	 */
	int METRIC = 1;

	/**
	 * The feature id for the '<em><b>Metric</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METRIC__METRIC = 0;

	/**
	 * The number of structural features of the '<em>Metric</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METRIC_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link Metrics.impl.SimpleMetricImpl <em>Simple Metric</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Metrics.impl.SimpleMetricImpl
	 * @see Metrics.impl.MetricsPackageImpl#getSimpleMetric()
	 * @generated
	 */
	int SIMPLE_METRIC = 2;

	/**
	 * The feature id for the '<em><b>Metric</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SIMPLE_METRIC__METRIC = METRIC__METRIC;

	/**
	 * The number of structural features of the '<em>Simple Metric</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SIMPLE_METRIC_FEATURE_COUNT = METRIC_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link Metrics.impl.SimpleIntegerMetricImpl <em>Simple Integer Metric</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Metrics.impl.SimpleIntegerMetricImpl
	 * @see Metrics.impl.MetricsPackageImpl#getSimpleIntegerMetric()
	 * @generated
	 */
	int SIMPLE_INTEGER_METRIC = 3;

	/**
	 * The feature id for the '<em><b>Metric</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SIMPLE_INTEGER_METRIC__METRIC = SIMPLE_METRIC__METRIC;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SIMPLE_INTEGER_METRIC__VALUE = SIMPLE_METRIC_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Simple Integer Metric</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SIMPLE_INTEGER_METRIC_FEATURE_COUNT = SIMPLE_METRIC_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link Metrics.impl.SimpleRealMetricImpl <em>Simple Real Metric</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Metrics.impl.SimpleRealMetricImpl
	 * @see Metrics.impl.MetricsPackageImpl#getSimpleRealMetric()
	 * @generated
	 */
	int SIMPLE_REAL_METRIC = 4;

	/**
	 * The feature id for the '<em><b>Metric</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SIMPLE_REAL_METRIC__METRIC = SIMPLE_METRIC__METRIC;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SIMPLE_REAL_METRIC__VALUE = SIMPLE_METRIC_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Simple Real Metric</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SIMPLE_REAL_METRIC_FEATURE_COUNT = SIMPLE_METRIC_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link Metrics.impl.AggregatedMetricImpl <em>Aggregated Metric</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Metrics.impl.AggregatedMetricImpl
	 * @see Metrics.impl.MetricsPackageImpl#getAggregatedMetric()
	 * @generated
	 */
	int AGGREGATED_METRIC = 7;

	/**
	 * The feature id for the '<em><b>Metric</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATED_METRIC__METRIC = METRIC__METRIC;

	/**
	 * The feature id for the '<em><b>Mean</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATED_METRIC__MEAN = METRIC_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Standard Deviation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATED_METRIC__STANDARD_DEVIATION = METRIC_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Gini Index</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATED_METRIC__GINI_INDEX = METRIC_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Theil Index</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATED_METRIC__THEIL_INDEX = METRIC_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Kolm Index</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATED_METRIC__KOLM_INDEX = METRIC_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Atkinson Index</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATED_METRIC__ATKINSON_INDEX = METRIC_FEATURE_COUNT + 5;

	/**
	 * The number of structural features of the '<em>Aggregated Metric</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATED_METRIC_FEATURE_COUNT = METRIC_FEATURE_COUNT + 6;

	/**
	 * The meta object id for the '{@link Metrics.impl.AggregatedIntegerMetricImpl <em>Aggregated Integer Metric</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Metrics.impl.AggregatedIntegerMetricImpl
	 * @see Metrics.impl.MetricsPackageImpl#getAggregatedIntegerMetric()
	 * @generated
	 */
	int AGGREGATED_INTEGER_METRIC = 5;

	/**
	 * The feature id for the '<em><b>Metric</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATED_INTEGER_METRIC__METRIC = AGGREGATED_METRIC__METRIC;

	/**
	 * The feature id for the '<em><b>Mean</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATED_INTEGER_METRIC__MEAN = AGGREGATED_METRIC__MEAN;

	/**
	 * The feature id for the '<em><b>Standard Deviation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATED_INTEGER_METRIC__STANDARD_DEVIATION = AGGREGATED_METRIC__STANDARD_DEVIATION;

	/**
	 * The feature id for the '<em><b>Gini Index</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATED_INTEGER_METRIC__GINI_INDEX = AGGREGATED_METRIC__GINI_INDEX;

	/**
	 * The feature id for the '<em><b>Theil Index</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATED_INTEGER_METRIC__THEIL_INDEX = AGGREGATED_METRIC__THEIL_INDEX;

	/**
	 * The feature id for the '<em><b>Kolm Index</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATED_INTEGER_METRIC__KOLM_INDEX = AGGREGATED_METRIC__KOLM_INDEX;

	/**
	 * The feature id for the '<em><b>Atkinson Index</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATED_INTEGER_METRIC__ATKINSON_INDEX = AGGREGATED_METRIC__ATKINSON_INDEX;

	/**
	 * The feature id for the '<em><b>Minimum</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATED_INTEGER_METRIC__MINIMUM = AGGREGATED_METRIC_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Maximum</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATED_INTEGER_METRIC__MAXIMUM = AGGREGATED_METRIC_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Median</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATED_INTEGER_METRIC__MEDIAN = AGGREGATED_METRIC_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Aggregated Integer Metric</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATED_INTEGER_METRIC_FEATURE_COUNT = AGGREGATED_METRIC_FEATURE_COUNT + 3;

	/**
	 * The meta object id for the '{@link Metrics.impl.AggregatedRealMetricImpl <em>Aggregated Real Metric</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Metrics.impl.AggregatedRealMetricImpl
	 * @see Metrics.impl.MetricsPackageImpl#getAggregatedRealMetric()
	 * @generated
	 */
	int AGGREGATED_REAL_METRIC = 6;

	/**
	 * The feature id for the '<em><b>Metric</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATED_REAL_METRIC__METRIC = AGGREGATED_METRIC__METRIC;

	/**
	 * The feature id for the '<em><b>Mean</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATED_REAL_METRIC__MEAN = AGGREGATED_METRIC__MEAN;

	/**
	 * The feature id for the '<em><b>Standard Deviation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATED_REAL_METRIC__STANDARD_DEVIATION = AGGREGATED_METRIC__STANDARD_DEVIATION;

	/**
	 * The feature id for the '<em><b>Gini Index</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATED_REAL_METRIC__GINI_INDEX = AGGREGATED_METRIC__GINI_INDEX;

	/**
	 * The feature id for the '<em><b>Theil Index</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATED_REAL_METRIC__THEIL_INDEX = AGGREGATED_METRIC__THEIL_INDEX;

	/**
	 * The feature id for the '<em><b>Kolm Index</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATED_REAL_METRIC__KOLM_INDEX = AGGREGATED_METRIC__KOLM_INDEX;

	/**
	 * The feature id for the '<em><b>Atkinson Index</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATED_REAL_METRIC__ATKINSON_INDEX = AGGREGATED_METRIC__ATKINSON_INDEX;

	/**
	 * The feature id for the '<em><b>Minimum</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATED_REAL_METRIC__MINIMUM = AGGREGATED_METRIC_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Maximum</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATED_REAL_METRIC__MAXIMUM = AGGREGATED_METRIC_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Median</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATED_REAL_METRIC__MEDIAN = AGGREGATED_METRIC_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Aggregated Real Metric</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATED_REAL_METRIC_FEATURE_COUNT = AGGREGATED_METRIC_FEATURE_COUNT + 3;


	/**
	 * Returns the meta object for class '{@link Metrics.Metrics <em>Metrics</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Metrics</em>'.
	 * @see Metrics.Metrics
	 * @generated
	 */
	EClass getMetrics();

	/**
	 * Returns the meta object for the containment reference list '{@link Metrics.Metrics#getSimpleMetrics <em>Simple Metrics</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Simple Metrics</em>'.
	 * @see Metrics.Metrics#getSimpleMetrics()
	 * @see #getMetrics()
	 * @generated
	 */
	EReference getMetrics_SimpleMetrics();

	/**
	 * Returns the meta object for the containment reference list '{@link Metrics.Metrics#getAggregatedIntegerMetrics <em>Aggregated Integer Metrics</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Aggregated Integer Metrics</em>'.
	 * @see Metrics.Metrics#getAggregatedIntegerMetrics()
	 * @see #getMetrics()
	 * @generated
	 */
	EReference getMetrics_AggregatedIntegerMetrics();

	/**
	 * Returns the meta object for the containment reference list '{@link Metrics.Metrics#getAggregatedRealMetrics <em>Aggregated Real Metrics</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Aggregated Real Metrics</em>'.
	 * @see Metrics.Metrics#getAggregatedRealMetrics()
	 * @see #getMetrics()
	 * @generated
	 */
	EReference getMetrics_AggregatedRealMetrics();

	/**
	 * Returns the meta object for the attribute '{@link Metrics.Metrics#getTrafoName <em>Trafo Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Trafo Name</em>'.
	 * @see Metrics.Metrics#getTrafoName()
	 * @see #getMetrics()
	 * @generated
	 */
	EAttribute getMetrics_TrafoName();

	/**
	 * Returns the meta object for the attribute '{@link Metrics.Metrics#getTrafoKind <em>Trafo Kind</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Trafo Kind</em>'.
	 * @see Metrics.Metrics#getTrafoKind()
	 * @see #getMetrics()
	 * @generated
	 */
	EAttribute getMetrics_TrafoKind();

	/**
	 * Returns the meta object for the attribute '{@link Metrics.Metrics#isHigherOrder <em>Higher Order</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Higher Order</em>'.
	 * @see Metrics.Metrics#isHigherOrder()
	 * @see #getMetrics()
	 * @generated
	 */
	EAttribute getMetrics_HigherOrder();

	/**
	 * Returns the meta object for class '{@link Metrics.Metric <em>Metric</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Metric</em>'.
	 * @see Metrics.Metric
	 * @generated
	 */
	EClass getMetric();

	/**
	 * Returns the meta object for the attribute '{@link Metrics.Metric#getMetric <em>Metric</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Metric</em>'.
	 * @see Metrics.Metric#getMetric()
	 * @see #getMetric()
	 * @generated
	 */
	EAttribute getMetric_Metric();

	/**
	 * Returns the meta object for class '{@link Metrics.SimpleMetric <em>Simple Metric</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Simple Metric</em>'.
	 * @see Metrics.SimpleMetric
	 * @generated
	 */
	EClass getSimpleMetric();

	/**
	 * Returns the meta object for class '{@link Metrics.SimpleIntegerMetric <em>Simple Integer Metric</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Simple Integer Metric</em>'.
	 * @see Metrics.SimpleIntegerMetric
	 * @generated
	 */
	EClass getSimpleIntegerMetric();

	/**
	 * Returns the meta object for the attribute '{@link Metrics.SimpleIntegerMetric#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see Metrics.SimpleIntegerMetric#getValue()
	 * @see #getSimpleIntegerMetric()
	 * @generated
	 */
	EAttribute getSimpleIntegerMetric_Value();

	/**
	 * Returns the meta object for class '{@link Metrics.SimpleRealMetric <em>Simple Real Metric</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Simple Real Metric</em>'.
	 * @see Metrics.SimpleRealMetric
	 * @generated
	 */
	EClass getSimpleRealMetric();

	/**
	 * Returns the meta object for the attribute '{@link Metrics.SimpleRealMetric#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see Metrics.SimpleRealMetric#getValue()
	 * @see #getSimpleRealMetric()
	 * @generated
	 */
	EAttribute getSimpleRealMetric_Value();

	/**
	 * Returns the meta object for class '{@link Metrics.AggregatedIntegerMetric <em>Aggregated Integer Metric</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Aggregated Integer Metric</em>'.
	 * @see Metrics.AggregatedIntegerMetric
	 * @generated
	 */
	EClass getAggregatedIntegerMetric();

	/**
	 * Returns the meta object for the attribute '{@link Metrics.AggregatedIntegerMetric#getMinimum <em>Minimum</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Minimum</em>'.
	 * @see Metrics.AggregatedIntegerMetric#getMinimum()
	 * @see #getAggregatedIntegerMetric()
	 * @generated
	 */
	EAttribute getAggregatedIntegerMetric_Minimum();

	/**
	 * Returns the meta object for the attribute '{@link Metrics.AggregatedIntegerMetric#getMaximum <em>Maximum</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Maximum</em>'.
	 * @see Metrics.AggregatedIntegerMetric#getMaximum()
	 * @see #getAggregatedIntegerMetric()
	 * @generated
	 */
	EAttribute getAggregatedIntegerMetric_Maximum();

	/**
	 * Returns the meta object for the attribute '{@link Metrics.AggregatedIntegerMetric#getMedian <em>Median</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Median</em>'.
	 * @see Metrics.AggregatedIntegerMetric#getMedian()
	 * @see #getAggregatedIntegerMetric()
	 * @generated
	 */
	EAttribute getAggregatedIntegerMetric_Median();

	/**
	 * Returns the meta object for class '{@link Metrics.AggregatedRealMetric <em>Aggregated Real Metric</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Aggregated Real Metric</em>'.
	 * @see Metrics.AggregatedRealMetric
	 * @generated
	 */
	EClass getAggregatedRealMetric();

	/**
	 * Returns the meta object for the attribute '{@link Metrics.AggregatedRealMetric#getMinimum <em>Minimum</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Minimum</em>'.
	 * @see Metrics.AggregatedRealMetric#getMinimum()
	 * @see #getAggregatedRealMetric()
	 * @generated
	 */
	EAttribute getAggregatedRealMetric_Minimum();

	/**
	 * Returns the meta object for the attribute '{@link Metrics.AggregatedRealMetric#getMaximum <em>Maximum</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Maximum</em>'.
	 * @see Metrics.AggregatedRealMetric#getMaximum()
	 * @see #getAggregatedRealMetric()
	 * @generated
	 */
	EAttribute getAggregatedRealMetric_Maximum();

	/**
	 * Returns the meta object for the attribute '{@link Metrics.AggregatedRealMetric#getMedian <em>Median</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Median</em>'.
	 * @see Metrics.AggregatedRealMetric#getMedian()
	 * @see #getAggregatedRealMetric()
	 * @generated
	 */
	EAttribute getAggregatedRealMetric_Median();

	/**
	 * Returns the meta object for class '{@link Metrics.AggregatedMetric <em>Aggregated Metric</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Aggregated Metric</em>'.
	 * @see Metrics.AggregatedMetric
	 * @generated
	 */
	EClass getAggregatedMetric();

	/**
	 * Returns the meta object for the attribute '{@link Metrics.AggregatedMetric#getMean <em>Mean</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Mean</em>'.
	 * @see Metrics.AggregatedMetric#getMean()
	 * @see #getAggregatedMetric()
	 * @generated
	 */
	EAttribute getAggregatedMetric_Mean();

	/**
	 * Returns the meta object for the attribute '{@link Metrics.AggregatedMetric#getStandardDeviation <em>Standard Deviation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Standard Deviation</em>'.
	 * @see Metrics.AggregatedMetric#getStandardDeviation()
	 * @see #getAggregatedMetric()
	 * @generated
	 */
	EAttribute getAggregatedMetric_StandardDeviation();

	/**
	 * Returns the meta object for the attribute '{@link Metrics.AggregatedMetric#getGiniIndex <em>Gini Index</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Gini Index</em>'.
	 * @see Metrics.AggregatedMetric#getGiniIndex()
	 * @see #getAggregatedMetric()
	 * @generated
	 */
	EAttribute getAggregatedMetric_GiniIndex();

	/**
	 * Returns the meta object for the attribute '{@link Metrics.AggregatedMetric#getTheilIndex <em>Theil Index</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Theil Index</em>'.
	 * @see Metrics.AggregatedMetric#getTheilIndex()
	 * @see #getAggregatedMetric()
	 * @generated
	 */
	EAttribute getAggregatedMetric_TheilIndex();

	/**
	 * Returns the meta object for the attribute '{@link Metrics.AggregatedMetric#getKolmIndex <em>Kolm Index</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Kolm Index</em>'.
	 * @see Metrics.AggregatedMetric#getKolmIndex()
	 * @see #getAggregatedMetric()
	 * @generated
	 */
	EAttribute getAggregatedMetric_KolmIndex();

	/**
	 * Returns the meta object for the attribute '{@link Metrics.AggregatedMetric#getAtkinsonIndex <em>Atkinson Index</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Atkinson Index</em>'.
	 * @see Metrics.AggregatedMetric#getAtkinsonIndex()
	 * @see #getAggregatedMetric()
	 * @generated
	 */
	EAttribute getAggregatedMetric_AtkinsonIndex();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	MetricsFactory getMetricsFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link Metrics.impl.MetricsImpl <em>Metrics</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Metrics.impl.MetricsImpl
		 * @see Metrics.impl.MetricsPackageImpl#getMetrics()
		 * @generated
		 */
		EClass METRICS = eINSTANCE.getMetrics();

		/**
		 * The meta object literal for the '<em><b>Simple Metrics</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference METRICS__SIMPLE_METRICS = eINSTANCE.getMetrics_SimpleMetrics();

		/**
		 * The meta object literal for the '<em><b>Aggregated Integer Metrics</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference METRICS__AGGREGATED_INTEGER_METRICS = eINSTANCE.getMetrics_AggregatedIntegerMetrics();

		/**
		 * The meta object literal for the '<em><b>Aggregated Real Metrics</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference METRICS__AGGREGATED_REAL_METRICS = eINSTANCE.getMetrics_AggregatedRealMetrics();

		/**
		 * The meta object literal for the '<em><b>Trafo Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute METRICS__TRAFO_NAME = eINSTANCE.getMetrics_TrafoName();

		/**
		 * The meta object literal for the '<em><b>Trafo Kind</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute METRICS__TRAFO_KIND = eINSTANCE.getMetrics_TrafoKind();

		/**
		 * The meta object literal for the '<em><b>Higher Order</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute METRICS__HIGHER_ORDER = eINSTANCE.getMetrics_HigherOrder();

		/**
		 * The meta object literal for the '{@link Metrics.impl.MetricImpl <em>Metric</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Metrics.impl.MetricImpl
		 * @see Metrics.impl.MetricsPackageImpl#getMetric()
		 * @generated
		 */
		EClass METRIC = eINSTANCE.getMetric();

		/**
		 * The meta object literal for the '<em><b>Metric</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute METRIC__METRIC = eINSTANCE.getMetric_Metric();

		/**
		 * The meta object literal for the '{@link Metrics.impl.SimpleMetricImpl <em>Simple Metric</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Metrics.impl.SimpleMetricImpl
		 * @see Metrics.impl.MetricsPackageImpl#getSimpleMetric()
		 * @generated
		 */
		EClass SIMPLE_METRIC = eINSTANCE.getSimpleMetric();

		/**
		 * The meta object literal for the '{@link Metrics.impl.SimpleIntegerMetricImpl <em>Simple Integer Metric</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Metrics.impl.SimpleIntegerMetricImpl
		 * @see Metrics.impl.MetricsPackageImpl#getSimpleIntegerMetric()
		 * @generated
		 */
		EClass SIMPLE_INTEGER_METRIC = eINSTANCE.getSimpleIntegerMetric();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SIMPLE_INTEGER_METRIC__VALUE = eINSTANCE.getSimpleIntegerMetric_Value();

		/**
		 * The meta object literal for the '{@link Metrics.impl.SimpleRealMetricImpl <em>Simple Real Metric</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Metrics.impl.SimpleRealMetricImpl
		 * @see Metrics.impl.MetricsPackageImpl#getSimpleRealMetric()
		 * @generated
		 */
		EClass SIMPLE_REAL_METRIC = eINSTANCE.getSimpleRealMetric();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SIMPLE_REAL_METRIC__VALUE = eINSTANCE.getSimpleRealMetric_Value();

		/**
		 * The meta object literal for the '{@link Metrics.impl.AggregatedIntegerMetricImpl <em>Aggregated Integer Metric</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Metrics.impl.AggregatedIntegerMetricImpl
		 * @see Metrics.impl.MetricsPackageImpl#getAggregatedIntegerMetric()
		 * @generated
		 */
		EClass AGGREGATED_INTEGER_METRIC = eINSTANCE.getAggregatedIntegerMetric();

		/**
		 * The meta object literal for the '<em><b>Minimum</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AGGREGATED_INTEGER_METRIC__MINIMUM = eINSTANCE.getAggregatedIntegerMetric_Minimum();

		/**
		 * The meta object literal for the '<em><b>Maximum</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AGGREGATED_INTEGER_METRIC__MAXIMUM = eINSTANCE.getAggregatedIntegerMetric_Maximum();

		/**
		 * The meta object literal for the '<em><b>Median</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AGGREGATED_INTEGER_METRIC__MEDIAN = eINSTANCE.getAggregatedIntegerMetric_Median();

		/**
		 * The meta object literal for the '{@link Metrics.impl.AggregatedRealMetricImpl <em>Aggregated Real Metric</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Metrics.impl.AggregatedRealMetricImpl
		 * @see Metrics.impl.MetricsPackageImpl#getAggregatedRealMetric()
		 * @generated
		 */
		EClass AGGREGATED_REAL_METRIC = eINSTANCE.getAggregatedRealMetric();

		/**
		 * The meta object literal for the '<em><b>Minimum</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AGGREGATED_REAL_METRIC__MINIMUM = eINSTANCE.getAggregatedRealMetric_Minimum();

		/**
		 * The meta object literal for the '<em><b>Maximum</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AGGREGATED_REAL_METRIC__MAXIMUM = eINSTANCE.getAggregatedRealMetric_Maximum();

		/**
		 * The meta object literal for the '<em><b>Median</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AGGREGATED_REAL_METRIC__MEDIAN = eINSTANCE.getAggregatedRealMetric_Median();

		/**
		 * The meta object literal for the '{@link Metrics.impl.AggregatedMetricImpl <em>Aggregated Metric</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Metrics.impl.AggregatedMetricImpl
		 * @see Metrics.impl.MetricsPackageImpl#getAggregatedMetric()
		 * @generated
		 */
		EClass AGGREGATED_METRIC = eINSTANCE.getAggregatedMetric();

		/**
		 * The meta object literal for the '<em><b>Mean</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AGGREGATED_METRIC__MEAN = eINSTANCE.getAggregatedMetric_Mean();

		/**
		 * The meta object literal for the '<em><b>Standard Deviation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AGGREGATED_METRIC__STANDARD_DEVIATION = eINSTANCE.getAggregatedMetric_StandardDeviation();

		/**
		 * The meta object literal for the '<em><b>Gini Index</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AGGREGATED_METRIC__GINI_INDEX = eINSTANCE.getAggregatedMetric_GiniIndex();

		/**
		 * The meta object literal for the '<em><b>Theil Index</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AGGREGATED_METRIC__THEIL_INDEX = eINSTANCE.getAggregatedMetric_TheilIndex();

		/**
		 * The meta object literal for the '<em><b>Kolm Index</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AGGREGATED_METRIC__KOLM_INDEX = eINSTANCE.getAggregatedMetric_KolmIndex();

		/**
		 * The meta object literal for the '<em><b>Atkinson Index</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AGGREGATED_METRIC__ATKINSON_INDEX = eINSTANCE.getAggregatedMetric_AtkinsonIndex();

	}

} //MetricsPackage
