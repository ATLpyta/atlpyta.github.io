/**
 */
package Metrics.impl;

import Metrics.AggregatedIntegerMetric;
import Metrics.AggregatedMetric;
import Metrics.AggregatedRealMetric;
import Metrics.Metric;
import Metrics.Metrics;
import Metrics.MetricsFactory;
import Metrics.MetricsPackage;
import Metrics.SimpleIntegerMetric;
import Metrics.SimpleMetric;
import Metrics.SimpleRealMetric;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class MetricsPackageImpl extends EPackageImpl implements MetricsPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass metricsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass metricEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass simpleMetricEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass simpleIntegerMetricEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass simpleRealMetricEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass aggregatedIntegerMetricEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass aggregatedRealMetricEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass aggregatedMetricEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see Metrics.MetricsPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private MetricsPackageImpl() {
		super(eNS_URI, MetricsFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link MetricsPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static MetricsPackage init() {
		if (isInited) return (MetricsPackage)EPackage.Registry.INSTANCE.getEPackage(MetricsPackage.eNS_URI);

		// Obtain or create and register package
		MetricsPackageImpl theMetricsPackage = (MetricsPackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof MetricsPackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new MetricsPackageImpl());

		isInited = true;

		// Create package meta-data objects
		theMetricsPackage.createPackageContents();

		// Initialize created meta-data
		theMetricsPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theMetricsPackage.freeze();

  
		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(MetricsPackage.eNS_URI, theMetricsPackage);
		return theMetricsPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMetrics() {
		return metricsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMetrics_SimpleMetrics() {
		return (EReference)metricsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMetrics_AggregatedIntegerMetrics() {
		return (EReference)metricsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMetrics_AggregatedRealMetrics() {
		return (EReference)metricsEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMetrics_TrafoName() {
		return (EAttribute)metricsEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMetrics_TrafoKind() {
		return (EAttribute)metricsEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMetrics_HigherOrder() {
		return (EAttribute)metricsEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMetric() {
		return metricEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMetric_Metric() {
		return (EAttribute)metricEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSimpleMetric() {
		return simpleMetricEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSimpleIntegerMetric() {
		return simpleIntegerMetricEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSimpleIntegerMetric_Value() {
		return (EAttribute)simpleIntegerMetricEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSimpleRealMetric() {
		return simpleRealMetricEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSimpleRealMetric_Value() {
		return (EAttribute)simpleRealMetricEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAggregatedIntegerMetric() {
		return aggregatedIntegerMetricEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAggregatedIntegerMetric_Minimum() {
		return (EAttribute)aggregatedIntegerMetricEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAggregatedIntegerMetric_Maximum() {
		return (EAttribute)aggregatedIntegerMetricEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAggregatedIntegerMetric_Median() {
		return (EAttribute)aggregatedIntegerMetricEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAggregatedRealMetric() {
		return aggregatedRealMetricEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAggregatedRealMetric_Minimum() {
		return (EAttribute)aggregatedRealMetricEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAggregatedRealMetric_Maximum() {
		return (EAttribute)aggregatedRealMetricEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAggregatedRealMetric_Median() {
		return (EAttribute)aggregatedRealMetricEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAggregatedMetric() {
		return aggregatedMetricEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAggregatedMetric_Mean() {
		return (EAttribute)aggregatedMetricEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAggregatedMetric_StandardDeviation() {
		return (EAttribute)aggregatedMetricEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAggregatedMetric_GiniIndex() {
		return (EAttribute)aggregatedMetricEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAggregatedMetric_TheilIndex() {
		return (EAttribute)aggregatedMetricEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAggregatedMetric_KolmIndex() {
		return (EAttribute)aggregatedMetricEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAggregatedMetric_AtkinsonIndex() {
		return (EAttribute)aggregatedMetricEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MetricsFactory getMetricsFactory() {
		return (MetricsFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		metricsEClass = createEClass(METRICS);
		createEReference(metricsEClass, METRICS__SIMPLE_METRICS);
		createEReference(metricsEClass, METRICS__AGGREGATED_INTEGER_METRICS);
		createEReference(metricsEClass, METRICS__AGGREGATED_REAL_METRICS);
		createEAttribute(metricsEClass, METRICS__TRAFO_NAME);
		createEAttribute(metricsEClass, METRICS__TRAFO_KIND);
		createEAttribute(metricsEClass, METRICS__HIGHER_ORDER);

		metricEClass = createEClass(METRIC);
		createEAttribute(metricEClass, METRIC__METRIC);

		simpleMetricEClass = createEClass(SIMPLE_METRIC);

		simpleIntegerMetricEClass = createEClass(SIMPLE_INTEGER_METRIC);
		createEAttribute(simpleIntegerMetricEClass, SIMPLE_INTEGER_METRIC__VALUE);

		simpleRealMetricEClass = createEClass(SIMPLE_REAL_METRIC);
		createEAttribute(simpleRealMetricEClass, SIMPLE_REAL_METRIC__VALUE);

		aggregatedIntegerMetricEClass = createEClass(AGGREGATED_INTEGER_METRIC);
		createEAttribute(aggregatedIntegerMetricEClass, AGGREGATED_INTEGER_METRIC__MINIMUM);
		createEAttribute(aggregatedIntegerMetricEClass, AGGREGATED_INTEGER_METRIC__MAXIMUM);
		createEAttribute(aggregatedIntegerMetricEClass, AGGREGATED_INTEGER_METRIC__MEDIAN);

		aggregatedRealMetricEClass = createEClass(AGGREGATED_REAL_METRIC);
		createEAttribute(aggregatedRealMetricEClass, AGGREGATED_REAL_METRIC__MINIMUM);
		createEAttribute(aggregatedRealMetricEClass, AGGREGATED_REAL_METRIC__MAXIMUM);
		createEAttribute(aggregatedRealMetricEClass, AGGREGATED_REAL_METRIC__MEDIAN);

		aggregatedMetricEClass = createEClass(AGGREGATED_METRIC);
		createEAttribute(aggregatedMetricEClass, AGGREGATED_METRIC__MEAN);
		createEAttribute(aggregatedMetricEClass, AGGREGATED_METRIC__STANDARD_DEVIATION);
		createEAttribute(aggregatedMetricEClass, AGGREGATED_METRIC__GINI_INDEX);
		createEAttribute(aggregatedMetricEClass, AGGREGATED_METRIC__THEIL_INDEX);
		createEAttribute(aggregatedMetricEClass, AGGREGATED_METRIC__KOLM_INDEX);
		createEAttribute(aggregatedMetricEClass, AGGREGATED_METRIC__ATKINSON_INDEX);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		simpleMetricEClass.getESuperTypes().add(this.getMetric());
		simpleIntegerMetricEClass.getESuperTypes().add(this.getSimpleMetric());
		simpleRealMetricEClass.getESuperTypes().add(this.getSimpleMetric());
		aggregatedIntegerMetricEClass.getESuperTypes().add(this.getAggregatedMetric());
		aggregatedRealMetricEClass.getESuperTypes().add(this.getAggregatedMetric());
		aggregatedMetricEClass.getESuperTypes().add(this.getMetric());

		// Initialize classes and features; add operations and parameters
		initEClass(metricsEClass, Metrics.class, "Metrics", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getMetrics_SimpleMetrics(), this.getSimpleMetric(), null, "SimpleMetrics", null, 0, -1, Metrics.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMetrics_AggregatedIntegerMetrics(), this.getAggregatedIntegerMetric(), null, "AggregatedIntegerMetrics", null, 0, -1, Metrics.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMetrics_AggregatedRealMetrics(), this.getAggregatedRealMetric(), null, "AggregatedRealMetrics", null, 0, -1, Metrics.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMetrics_TrafoName(), ecorePackage.getEString(), "TrafoName", null, 1, 1, Metrics.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMetrics_TrafoKind(), ecorePackage.getEInt(), "trafoKind", null, 0, 1, Metrics.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMetrics_HigherOrder(), ecorePackage.getEBoolean(), "higherOrder", null, 0, 1, Metrics.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(metricEClass, Metric.class, "Metric", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getMetric_Metric(), ecorePackage.getEString(), "Metric", null, 1, 1, Metric.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(simpleMetricEClass, SimpleMetric.class, "SimpleMetric", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(simpleIntegerMetricEClass, SimpleIntegerMetric.class, "SimpleIntegerMetric", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSimpleIntegerMetric_Value(), ecorePackage.getEInt(), "Value", null, 1, 1, SimpleIntegerMetric.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(simpleRealMetricEClass, SimpleRealMetric.class, "SimpleRealMetric", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSimpleRealMetric_Value(), ecorePackage.getEDouble(), "Value", null, 1, 1, SimpleRealMetric.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(aggregatedIntegerMetricEClass, AggregatedIntegerMetric.class, "AggregatedIntegerMetric", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAggregatedIntegerMetric_Minimum(), ecorePackage.getEInt(), "Minimum", null, 1, 1, AggregatedIntegerMetric.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAggregatedIntegerMetric_Maximum(), ecorePackage.getEInt(), "Maximum", null, 1, 1, AggregatedIntegerMetric.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAggregatedIntegerMetric_Median(), ecorePackage.getEInt(), "Median", null, 1, 1, AggregatedIntegerMetric.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(aggregatedRealMetricEClass, AggregatedRealMetric.class, "AggregatedRealMetric", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAggregatedRealMetric_Minimum(), ecorePackage.getEFloat(), "Minimum", null, 1, 1, AggregatedRealMetric.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAggregatedRealMetric_Maximum(), ecorePackage.getEFloat(), "Maximum", null, 1, 1, AggregatedRealMetric.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAggregatedRealMetric_Median(), ecorePackage.getEFloat(), "Median", null, 1, 1, AggregatedRealMetric.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(aggregatedMetricEClass, AggregatedMetric.class, "AggregatedMetric", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAggregatedMetric_Mean(), ecorePackage.getEFloat(), "Mean", null, 1, 1, AggregatedMetric.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAggregatedMetric_StandardDeviation(), ecorePackage.getEFloat(), "StandardDeviation", null, 1, 1, AggregatedMetric.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAggregatedMetric_GiniIndex(), ecorePackage.getEFloat(), "GiniIndex", null, 1, 1, AggregatedMetric.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAggregatedMetric_TheilIndex(), ecorePackage.getEFloat(), "TheilIndex", null, 1, 1, AggregatedMetric.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAggregatedMetric_KolmIndex(), ecorePackage.getEFloat(), "KolmIndex", null, 1, 1, AggregatedMetric.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAggregatedMetric_AtkinsonIndex(), ecorePackage.getEFloat(), "AtkinsonIndex", null, 1, 1, AggregatedMetric.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Create resource
		createResource(eNS_URI);
	}

} //MetricsPackageImpl
