/**
 */
package Metrics.impl;

import Metrics.AggregatedIntegerMetric;
import Metrics.AggregatedRealMetric;
import Metrics.Metrics;
import Metrics.MetricsPackage;
import Metrics.SimpleMetric;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Metrics</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link Metrics.impl.MetricsImpl#getSimpleMetrics <em>Simple Metrics</em>}</li>
 *   <li>{@link Metrics.impl.MetricsImpl#getAggregatedIntegerMetrics <em>Aggregated Integer Metrics</em>}</li>
 *   <li>{@link Metrics.impl.MetricsImpl#getAggregatedRealMetrics <em>Aggregated Real Metrics</em>}</li>
 *   <li>{@link Metrics.impl.MetricsImpl#getTrafoName <em>Trafo Name</em>}</li>
 *   <li>{@link Metrics.impl.MetricsImpl#getTrafoKind <em>Trafo Kind</em>}</li>
 *   <li>{@link Metrics.impl.MetricsImpl#isHigherOrder <em>Higher Order</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class MetricsImpl extends EObjectImpl implements Metrics {
	/**
	 * The cached value of the '{@link #getSimpleMetrics() <em>Simple Metrics</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSimpleMetrics()
	 * @generated
	 * @ordered
	 */
	protected EList<SimpleMetric> simpleMetrics;

	/**
	 * The cached value of the '{@link #getAggregatedIntegerMetrics() <em>Aggregated Integer Metrics</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAggregatedIntegerMetrics()
	 * @generated
	 * @ordered
	 */
	protected EList<AggregatedIntegerMetric> aggregatedIntegerMetrics;

	/**
	 * The cached value of the '{@link #getAggregatedRealMetrics() <em>Aggregated Real Metrics</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAggregatedRealMetrics()
	 * @generated
	 * @ordered
	 */
	protected EList<AggregatedRealMetric> aggregatedRealMetrics;

	/**
	 * The default value of the '{@link #getTrafoName() <em>Trafo Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrafoName()
	 * @generated
	 * @ordered
	 */
	protected static final String TRAFO_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTrafoName() <em>Trafo Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrafoName()
	 * @generated
	 * @ordered
	 */
	protected String trafoName = TRAFO_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getTrafoKind() <em>Trafo Kind</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrafoKind()
	 * @generated
	 * @ordered
	 */
	protected static final int TRAFO_KIND_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getTrafoKind() <em>Trafo Kind</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrafoKind()
	 * @generated
	 * @ordered
	 */
	protected int trafoKind = TRAFO_KIND_EDEFAULT;

	/**
	 * The default value of the '{@link #isHigherOrder() <em>Higher Order</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isHigherOrder()
	 * @generated
	 * @ordered
	 */
	protected static final boolean HIGHER_ORDER_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isHigherOrder() <em>Higher Order</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isHigherOrder()
	 * @generated
	 * @ordered
	 */
	protected boolean higherOrder = HIGHER_ORDER_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MetricsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MetricsPackage.Literals.METRICS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<SimpleMetric> getSimpleMetrics() {
		if (simpleMetrics == null) {
			simpleMetrics = new EObjectContainmentEList<SimpleMetric>(SimpleMetric.class, this, MetricsPackage.METRICS__SIMPLE_METRICS);
		}
		return simpleMetrics;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<AggregatedIntegerMetric> getAggregatedIntegerMetrics() {
		if (aggregatedIntegerMetrics == null) {
			aggregatedIntegerMetrics = new EObjectContainmentEList<AggregatedIntegerMetric>(AggregatedIntegerMetric.class, this, MetricsPackage.METRICS__AGGREGATED_INTEGER_METRICS);
		}
		return aggregatedIntegerMetrics;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<AggregatedRealMetric> getAggregatedRealMetrics() {
		if (aggregatedRealMetrics == null) {
			aggregatedRealMetrics = new EObjectContainmentEList<AggregatedRealMetric>(AggregatedRealMetric.class, this, MetricsPackage.METRICS__AGGREGATED_REAL_METRICS);
		}
		return aggregatedRealMetrics;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTrafoName() {
		return trafoName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTrafoName(String newTrafoName) {
		String oldTrafoName = trafoName;
		trafoName = newTrafoName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MetricsPackage.METRICS__TRAFO_NAME, oldTrafoName, trafoName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getTrafoKind() {
		return trafoKind;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTrafoKind(int newTrafoKind) {
		int oldTrafoKind = trafoKind;
		trafoKind = newTrafoKind;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MetricsPackage.METRICS__TRAFO_KIND, oldTrafoKind, trafoKind));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isHigherOrder() {
		return higherOrder;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHigherOrder(boolean newHigherOrder) {
		boolean oldHigherOrder = higherOrder;
		higherOrder = newHigherOrder;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MetricsPackage.METRICS__HIGHER_ORDER, oldHigherOrder, higherOrder));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case MetricsPackage.METRICS__SIMPLE_METRICS:
				return ((InternalEList<?>)getSimpleMetrics()).basicRemove(otherEnd, msgs);
			case MetricsPackage.METRICS__AGGREGATED_INTEGER_METRICS:
				return ((InternalEList<?>)getAggregatedIntegerMetrics()).basicRemove(otherEnd, msgs);
			case MetricsPackage.METRICS__AGGREGATED_REAL_METRICS:
				return ((InternalEList<?>)getAggregatedRealMetrics()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case MetricsPackage.METRICS__SIMPLE_METRICS:
				return getSimpleMetrics();
			case MetricsPackage.METRICS__AGGREGATED_INTEGER_METRICS:
				return getAggregatedIntegerMetrics();
			case MetricsPackage.METRICS__AGGREGATED_REAL_METRICS:
				return getAggregatedRealMetrics();
			case MetricsPackage.METRICS__TRAFO_NAME:
				return getTrafoName();
			case MetricsPackage.METRICS__TRAFO_KIND:
				return getTrafoKind();
			case MetricsPackage.METRICS__HIGHER_ORDER:
				return isHigherOrder();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case MetricsPackage.METRICS__SIMPLE_METRICS:
				getSimpleMetrics().clear();
				getSimpleMetrics().addAll((Collection<? extends SimpleMetric>)newValue);
				return;
			case MetricsPackage.METRICS__AGGREGATED_INTEGER_METRICS:
				getAggregatedIntegerMetrics().clear();
				getAggregatedIntegerMetrics().addAll((Collection<? extends AggregatedIntegerMetric>)newValue);
				return;
			case MetricsPackage.METRICS__AGGREGATED_REAL_METRICS:
				getAggregatedRealMetrics().clear();
				getAggregatedRealMetrics().addAll((Collection<? extends AggregatedRealMetric>)newValue);
				return;
			case MetricsPackage.METRICS__TRAFO_NAME:
				setTrafoName((String)newValue);
				return;
			case MetricsPackage.METRICS__TRAFO_KIND:
				setTrafoKind((Integer)newValue);
				return;
			case MetricsPackage.METRICS__HIGHER_ORDER:
				setHigherOrder((Boolean)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case MetricsPackage.METRICS__SIMPLE_METRICS:
				getSimpleMetrics().clear();
				return;
			case MetricsPackage.METRICS__AGGREGATED_INTEGER_METRICS:
				getAggregatedIntegerMetrics().clear();
				return;
			case MetricsPackage.METRICS__AGGREGATED_REAL_METRICS:
				getAggregatedRealMetrics().clear();
				return;
			case MetricsPackage.METRICS__TRAFO_NAME:
				setTrafoName(TRAFO_NAME_EDEFAULT);
				return;
			case MetricsPackage.METRICS__TRAFO_KIND:
				setTrafoKind(TRAFO_KIND_EDEFAULT);
				return;
			case MetricsPackage.METRICS__HIGHER_ORDER:
				setHigherOrder(HIGHER_ORDER_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case MetricsPackage.METRICS__SIMPLE_METRICS:
				return simpleMetrics != null && !simpleMetrics.isEmpty();
			case MetricsPackage.METRICS__AGGREGATED_INTEGER_METRICS:
				return aggregatedIntegerMetrics != null && !aggregatedIntegerMetrics.isEmpty();
			case MetricsPackage.METRICS__AGGREGATED_REAL_METRICS:
				return aggregatedRealMetrics != null && !aggregatedRealMetrics.isEmpty();
			case MetricsPackage.METRICS__TRAFO_NAME:
				return TRAFO_NAME_EDEFAULT == null ? trafoName != null : !TRAFO_NAME_EDEFAULT.equals(trafoName);
			case MetricsPackage.METRICS__TRAFO_KIND:
				return trafoKind != TRAFO_KIND_EDEFAULT;
			case MetricsPackage.METRICS__HIGHER_ORDER:
				return higherOrder != HIGHER_ORDER_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (TrafoName: ");
		result.append(trafoName);
		result.append(", trafoKind: ");
		result.append(trafoKind);
		result.append(", higherOrder: ");
		result.append(higherOrder);
		result.append(')');
		return result.toString();
	}

} //MetricsImpl
