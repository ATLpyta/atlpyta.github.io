/**
 */
package Metrics.impl;

import Metrics.AggregatedMetric;
import Metrics.MetricsPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Aggregated Metric</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link Metrics.impl.AggregatedMetricImpl#getMean <em>Mean</em>}</li>
 *   <li>{@link Metrics.impl.AggregatedMetricImpl#getStandardDeviation <em>Standard Deviation</em>}</li>
 *   <li>{@link Metrics.impl.AggregatedMetricImpl#getGiniIndex <em>Gini Index</em>}</li>
 *   <li>{@link Metrics.impl.AggregatedMetricImpl#getTheilIndex <em>Theil Index</em>}</li>
 *   <li>{@link Metrics.impl.AggregatedMetricImpl#getKolmIndex <em>Kolm Index</em>}</li>
 *   <li>{@link Metrics.impl.AggregatedMetricImpl#getAtkinsonIndex <em>Atkinson Index</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public abstract class AggregatedMetricImpl extends MetricImpl implements AggregatedMetric {
	/**
	 * The default value of the '{@link #getMean() <em>Mean</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMean()
	 * @generated
	 * @ordered
	 */
	protected static final float MEAN_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getMean() <em>Mean</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMean()
	 * @generated
	 * @ordered
	 */
	protected float mean = MEAN_EDEFAULT;

	/**
	 * The default value of the '{@link #getStandardDeviation() <em>Standard Deviation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStandardDeviation()
	 * @generated
	 * @ordered
	 */
	protected static final float STANDARD_DEVIATION_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getStandardDeviation() <em>Standard Deviation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStandardDeviation()
	 * @generated
	 * @ordered
	 */
	protected float standardDeviation = STANDARD_DEVIATION_EDEFAULT;

	/**
	 * The default value of the '{@link #getGiniIndex() <em>Gini Index</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGiniIndex()
	 * @generated
	 * @ordered
	 */
	protected static final float GINI_INDEX_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getGiniIndex() <em>Gini Index</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGiniIndex()
	 * @generated
	 * @ordered
	 */
	protected float giniIndex = GINI_INDEX_EDEFAULT;

	/**
	 * The default value of the '{@link #getTheilIndex() <em>Theil Index</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTheilIndex()
	 * @generated
	 * @ordered
	 */
	protected static final float THEIL_INDEX_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getTheilIndex() <em>Theil Index</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTheilIndex()
	 * @generated
	 * @ordered
	 */
	protected float theilIndex = THEIL_INDEX_EDEFAULT;

	/**
	 * The default value of the '{@link #getKolmIndex() <em>Kolm Index</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getKolmIndex()
	 * @generated
	 * @ordered
	 */
	protected static final float KOLM_INDEX_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getKolmIndex() <em>Kolm Index</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getKolmIndex()
	 * @generated
	 * @ordered
	 */
	protected float kolmIndex = KOLM_INDEX_EDEFAULT;

	/**
	 * The default value of the '{@link #getAtkinsonIndex() <em>Atkinson Index</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAtkinsonIndex()
	 * @generated
	 * @ordered
	 */
	protected static final float ATKINSON_INDEX_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getAtkinsonIndex() <em>Atkinson Index</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAtkinsonIndex()
	 * @generated
	 * @ordered
	 */
	protected float atkinsonIndex = ATKINSON_INDEX_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AggregatedMetricImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MetricsPackage.Literals.AGGREGATED_METRIC;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public float getMean() {
		return mean;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMean(float newMean) {
		float oldMean = mean;
		mean = newMean;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MetricsPackage.AGGREGATED_METRIC__MEAN, oldMean, mean));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public float getStandardDeviation() {
		return standardDeviation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setStandardDeviation(float newStandardDeviation) {
		float oldStandardDeviation = standardDeviation;
		standardDeviation = newStandardDeviation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MetricsPackage.AGGREGATED_METRIC__STANDARD_DEVIATION, oldStandardDeviation, standardDeviation));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public float getGiniIndex() {
		return giniIndex;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setGiniIndex(float newGiniIndex) {
		float oldGiniIndex = giniIndex;
		giniIndex = newGiniIndex;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MetricsPackage.AGGREGATED_METRIC__GINI_INDEX, oldGiniIndex, giniIndex));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public float getTheilIndex() {
		return theilIndex;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTheilIndex(float newTheilIndex) {
		float oldTheilIndex = theilIndex;
		theilIndex = newTheilIndex;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MetricsPackage.AGGREGATED_METRIC__THEIL_INDEX, oldTheilIndex, theilIndex));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public float getKolmIndex() {
		return kolmIndex;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setKolmIndex(float newKolmIndex) {
		float oldKolmIndex = kolmIndex;
		kolmIndex = newKolmIndex;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MetricsPackage.AGGREGATED_METRIC__KOLM_INDEX, oldKolmIndex, kolmIndex));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public float getAtkinsonIndex() {
		return atkinsonIndex;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAtkinsonIndex(float newAtkinsonIndex) {
		float oldAtkinsonIndex = atkinsonIndex;
		atkinsonIndex = newAtkinsonIndex;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MetricsPackage.AGGREGATED_METRIC__ATKINSON_INDEX, oldAtkinsonIndex, atkinsonIndex));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case MetricsPackage.AGGREGATED_METRIC__MEAN:
				return getMean();
			case MetricsPackage.AGGREGATED_METRIC__STANDARD_DEVIATION:
				return getStandardDeviation();
			case MetricsPackage.AGGREGATED_METRIC__GINI_INDEX:
				return getGiniIndex();
			case MetricsPackage.AGGREGATED_METRIC__THEIL_INDEX:
				return getTheilIndex();
			case MetricsPackage.AGGREGATED_METRIC__KOLM_INDEX:
				return getKolmIndex();
			case MetricsPackage.AGGREGATED_METRIC__ATKINSON_INDEX:
				return getAtkinsonIndex();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case MetricsPackage.AGGREGATED_METRIC__MEAN:
				setMean((Float)newValue);
				return;
			case MetricsPackage.AGGREGATED_METRIC__STANDARD_DEVIATION:
				setStandardDeviation((Float)newValue);
				return;
			case MetricsPackage.AGGREGATED_METRIC__GINI_INDEX:
				setGiniIndex((Float)newValue);
				return;
			case MetricsPackage.AGGREGATED_METRIC__THEIL_INDEX:
				setTheilIndex((Float)newValue);
				return;
			case MetricsPackage.AGGREGATED_METRIC__KOLM_INDEX:
				setKolmIndex((Float)newValue);
				return;
			case MetricsPackage.AGGREGATED_METRIC__ATKINSON_INDEX:
				setAtkinsonIndex((Float)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case MetricsPackage.AGGREGATED_METRIC__MEAN:
				setMean(MEAN_EDEFAULT);
				return;
			case MetricsPackage.AGGREGATED_METRIC__STANDARD_DEVIATION:
				setStandardDeviation(STANDARD_DEVIATION_EDEFAULT);
				return;
			case MetricsPackage.AGGREGATED_METRIC__GINI_INDEX:
				setGiniIndex(GINI_INDEX_EDEFAULT);
				return;
			case MetricsPackage.AGGREGATED_METRIC__THEIL_INDEX:
				setTheilIndex(THEIL_INDEX_EDEFAULT);
				return;
			case MetricsPackage.AGGREGATED_METRIC__KOLM_INDEX:
				setKolmIndex(KOLM_INDEX_EDEFAULT);
				return;
			case MetricsPackage.AGGREGATED_METRIC__ATKINSON_INDEX:
				setAtkinsonIndex(ATKINSON_INDEX_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case MetricsPackage.AGGREGATED_METRIC__MEAN:
				return mean != MEAN_EDEFAULT;
			case MetricsPackage.AGGREGATED_METRIC__STANDARD_DEVIATION:
				return standardDeviation != STANDARD_DEVIATION_EDEFAULT;
			case MetricsPackage.AGGREGATED_METRIC__GINI_INDEX:
				return giniIndex != GINI_INDEX_EDEFAULT;
			case MetricsPackage.AGGREGATED_METRIC__THEIL_INDEX:
				return theilIndex != THEIL_INDEX_EDEFAULT;
			case MetricsPackage.AGGREGATED_METRIC__KOLM_INDEX:
				return kolmIndex != KOLM_INDEX_EDEFAULT;
			case MetricsPackage.AGGREGATED_METRIC__ATKINSON_INDEX:
				return atkinsonIndex != ATKINSON_INDEX_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (Mean: ");
		result.append(mean);
		result.append(", StandardDeviation: ");
		result.append(standardDeviation);
		result.append(", GiniIndex: ");
		result.append(giniIndex);
		result.append(", TheilIndex: ");
		result.append(theilIndex);
		result.append(", KolmIndex: ");
		result.append(kolmIndex);
		result.append(", AtkinsonIndex: ");
		result.append(atkinsonIndex);
		result.append(')');
		return result.toString();
	}

} //AggregatedMetricImpl
