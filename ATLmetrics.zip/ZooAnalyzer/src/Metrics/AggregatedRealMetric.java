/**
 */
package Metrics;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Aggregated Real Metric</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link Metrics.AggregatedRealMetric#getMinimum <em>Minimum</em>}</li>
 *   <li>{@link Metrics.AggregatedRealMetric#getMaximum <em>Maximum</em>}</li>
 *   <li>{@link Metrics.AggregatedRealMetric#getMedian <em>Median</em>}</li>
 * </ul>
 * </p>
 *
 * @see Metrics.MetricsPackage#getAggregatedRealMetric()
 * @model
 * @generated
 */
public interface AggregatedRealMetric extends AggregatedMetric {
	/**
	 * Returns the value of the '<em><b>Minimum</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Minimum</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Minimum</em>' attribute.
	 * @see #setMinimum(float)
	 * @see Metrics.MetricsPackage#getAggregatedRealMetric_Minimum()
	 * @model required="true"
	 * @generated
	 */
	float getMinimum();

	/**
	 * Sets the value of the '{@link Metrics.AggregatedRealMetric#getMinimum <em>Minimum</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Minimum</em>' attribute.
	 * @see #getMinimum()
	 * @generated
	 */
	void setMinimum(float value);

	/**
	 * Returns the value of the '<em><b>Maximum</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Maximum</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Maximum</em>' attribute.
	 * @see #setMaximum(float)
	 * @see Metrics.MetricsPackage#getAggregatedRealMetric_Maximum()
	 * @model required="true"
	 * @generated
	 */
	float getMaximum();

	/**
	 * Sets the value of the '{@link Metrics.AggregatedRealMetric#getMaximum <em>Maximum</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Maximum</em>' attribute.
	 * @see #getMaximum()
	 * @generated
	 */
	void setMaximum(float value);

	/**
	 * Returns the value of the '<em><b>Median</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Median</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Median</em>' attribute.
	 * @see #setMedian(float)
	 * @see Metrics.MetricsPackage#getAggregatedRealMetric_Median()
	 * @model required="true"
	 * @generated
	 */
	float getMedian();

	/**
	 * Sets the value of the '{@link Metrics.AggregatedRealMetric#getMedian <em>Median</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Median</em>' attribute.
	 * @see #getMedian()
	 * @generated
	 */
	void setMedian(float value);

} // AggregatedRealMetric
