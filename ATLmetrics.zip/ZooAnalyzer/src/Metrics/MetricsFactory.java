/**
 */
package Metrics;

import org.eclipse.emf.ecore.EFactory;
import Metrics.impl.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see Metrics.MetricsPackage
 * @generated
 */
public interface MetricsFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	MetricsFactory eINSTANCE = MetricsFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Metrics</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Metrics</em>'.
	 * @generated
	 */
	Metrics createMetrics();

	/**
	 * Returns a new object of class '<em>Simple Integer Metric</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Simple Integer Metric</em>'.
	 * @generated
	 */
	SimpleIntegerMetric createSimpleIntegerMetric();

	/**
	 * Returns a new object of class '<em>Simple Real Metric</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Simple Real Metric</em>'.
	 * @generated
	 */
	SimpleRealMetric createSimpleRealMetric();

	/**
	 * Returns a new object of class '<em>Aggregated Integer Metric</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Aggregated Integer Metric</em>'.
	 * @generated
	 */
	AggregatedIntegerMetric createAggregatedIntegerMetric();

	/**
	 * Returns a new object of class '<em>Aggregated Real Metric</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Aggregated Real Metric</em>'.
	 * @generated
	 */
	AggregatedRealMetric createAggregatedRealMetric();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	MetricsPackage getMetricsPackage();

} //MetricsFactory
