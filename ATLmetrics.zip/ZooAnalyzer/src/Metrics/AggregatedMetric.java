/**
 */
package Metrics;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Aggregated Metric</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link Metrics.AggregatedMetric#getMean <em>Mean</em>}</li>
 *   <li>{@link Metrics.AggregatedMetric#getStandardDeviation <em>Standard Deviation</em>}</li>
 *   <li>{@link Metrics.AggregatedMetric#getGiniIndex <em>Gini Index</em>}</li>
 *   <li>{@link Metrics.AggregatedMetric#getTheilIndex <em>Theil Index</em>}</li>
 *   <li>{@link Metrics.AggregatedMetric#getKolmIndex <em>Kolm Index</em>}</li>
 *   <li>{@link Metrics.AggregatedMetric#getAtkinsonIndex <em>Atkinson Index</em>}</li>
 * </ul>
 * </p>
 *
 * @see Metrics.MetricsPackage#getAggregatedMetric()
 * @model abstract="true"
 * @generated
 */
public interface AggregatedMetric extends Metric {
	/**
	 * Returns the value of the '<em><b>Mean</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Mean</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Mean</em>' attribute.
	 * @see #setMean(float)
	 * @see Metrics.MetricsPackage#getAggregatedMetric_Mean()
	 * @model required="true"
	 * @generated
	 */
	float getMean();

	/**
	 * Sets the value of the '{@link Metrics.AggregatedMetric#getMean <em>Mean</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Mean</em>' attribute.
	 * @see #getMean()
	 * @generated
	 */
	void setMean(float value);

	/**
	 * Returns the value of the '<em><b>Standard Deviation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Standard Deviation</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Standard Deviation</em>' attribute.
	 * @see #setStandardDeviation(float)
	 * @see Metrics.MetricsPackage#getAggregatedMetric_StandardDeviation()
	 * @model required="true"
	 * @generated
	 */
	float getStandardDeviation();

	/**
	 * Sets the value of the '{@link Metrics.AggregatedMetric#getStandardDeviation <em>Standard Deviation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Standard Deviation</em>' attribute.
	 * @see #getStandardDeviation()
	 * @generated
	 */
	void setStandardDeviation(float value);

	/**
	 * Returns the value of the '<em><b>Gini Index</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Gini Index</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Gini Index</em>' attribute.
	 * @see #setGiniIndex(float)
	 * @see Metrics.MetricsPackage#getAggregatedMetric_GiniIndex()
	 * @model required="true"
	 * @generated
	 */
	float getGiniIndex();

	/**
	 * Sets the value of the '{@link Metrics.AggregatedMetric#getGiniIndex <em>Gini Index</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Gini Index</em>' attribute.
	 * @see #getGiniIndex()
	 * @generated
	 */
	void setGiniIndex(float value);

	/**
	 * Returns the value of the '<em><b>Theil Index</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Theil Index</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Theil Index</em>' attribute.
	 * @see #setTheilIndex(float)
	 * @see Metrics.MetricsPackage#getAggregatedMetric_TheilIndex()
	 * @model required="true"
	 * @generated
	 */
	float getTheilIndex();

	/**
	 * Sets the value of the '{@link Metrics.AggregatedMetric#getTheilIndex <em>Theil Index</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Theil Index</em>' attribute.
	 * @see #getTheilIndex()
	 * @generated
	 */
	void setTheilIndex(float value);

	/**
	 * Returns the value of the '<em><b>Kolm Index</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Kolm Index</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Kolm Index</em>' attribute.
	 * @see #setKolmIndex(float)
	 * @see Metrics.MetricsPackage#getAggregatedMetric_KolmIndex()
	 * @model required="true"
	 * @generated
	 */
	float getKolmIndex();

	/**
	 * Sets the value of the '{@link Metrics.AggregatedMetric#getKolmIndex <em>Kolm Index</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Kolm Index</em>' attribute.
	 * @see #getKolmIndex()
	 * @generated
	 */
	void setKolmIndex(float value);

	/**
	 * Returns the value of the '<em><b>Atkinson Index</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Atkinson Index</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Atkinson Index</em>' attribute.
	 * @see #setAtkinsonIndex(float)
	 * @see Metrics.MetricsPackage#getAggregatedMetric_AtkinsonIndex()
	 * @model required="true"
	 * @generated
	 */
	float getAtkinsonIndex();

	/**
	 * Sets the value of the '{@link Metrics.AggregatedMetric#getAtkinsonIndex <em>Atkinson Index</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Atkinson Index</em>' attribute.
	 * @see #getAtkinsonIndex()
	 * @generated
	 */
	void setAtkinsonIndex(float value);

} // AggregatedMetric
