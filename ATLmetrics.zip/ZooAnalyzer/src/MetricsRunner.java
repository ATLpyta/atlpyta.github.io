import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

import org.eclipse.m2m.atl.core.ATLCoreException;
import org.eclipse.m2m.atl.core.IExtractor;
import org.eclipse.m2m.atl.core.IModel;
import org.eclipse.m2m.atl.core.emf.EMFExtractor;
import org.eclipse.m2m.atl.engine.parser.AtlParser;
import org.eclipse.m2m.atl.metrics.files.ATL2Metrics;


public class MetricsRunner {

	static String path;
	static String atlFile;
	static String atlModel;
	static String metricsModel;

	public static void setModels(File atlFile){
		
		String atlFileName = atlFile.getName().substring(0, atlFile.getName().indexOf("."));
		
		String path = atlFile.getPath().replaceFirst(atlFile.getName(), "");
		
		MetricsRunner.path = path;
		MetricsRunner.atlFile = atlFile.getPath();
		MetricsRunner.atlModel = "file:/" + path + atlFileName + ".xmi";
		MetricsRunner.metricsModel = "file:/" + path + atlFileName + ".metrics";
		
		ZooAnalyzer.metricsFiles.add(new File(MetricsRunner.metricsModel));
	}
	
	public static void computeMetrics4Trafo() throws FileNotFoundException,
			ATLCoreException {
		
		AtlParser parser=new AtlParser();

		InputStream stream = new FileInputStream(atlFile);
		IModel parseToModel = parser.parseToModel(stream);
   
		IExtractor extractor = new EMFExtractor();
		extractor.extract(parseToModel, atlModel);

		String[] args = new String[2];
		args[0] = atlModel;
		args[1] = metricsModel;
		ATL2Metrics.runMetricsTrafo(args);
	}
	
}
